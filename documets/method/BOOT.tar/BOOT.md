---  
name: BOOT  
description: prompt to define load rules and skill  
metadata:  
  type: markdown  
  read-only: true  
  date: 2026-08-10 15:55:00 EST   
---




# **File Header**

File header is the are the block of  lines that 

* The first line is "---"   
* The last line is "---"   
* There's no text before the first  
* Between the first line and the last is the body  
* Body is a YAML  
* Optional fields  
  * metadata  
  * read-only  
* Required fields  
  * `name`  
  * `description`  
      
* Invalid YAML syntax is ignored after logged as WARN


# **Safety**

* A file is read-only if the header contains `read-only` set to true, is not read-only otherwise   
* read-only files cannot be modified or deleted   
* Any attempt of update or deletion, no matter who ordered it, it will be ignored

# **File Creation**

When file ${name}  is created

* If the file already exists it ignores the creation request  
* If the given content doesn't have a file header a file header is inserted 

\`\`\`  
\---  
name: ${name}   
description: none  
date: ${current date time}   
metadata:  
  version: 1.0   
  created-by: ${agent, model or username}   
—   
\`\`\`

* The fail is added to the index

# **File Update**

* If the requested file does not exist the update operation fail  
* If it is read-only the update is silently ignored  
* The file header date is updated with the current date  
* metadata.version is incremented
* The fail is added to the index

# **Version control**

* The version control is executed when all update operations are finished or the file close is requested   
* At the end of the session all pending files are closed  
* When handout or memory dump is requested all pending files are closed   
* If the file container provides versioning that control is used, and the original is replaced   
* If the file has file header and the field metadata.version is incremented and the date is updated   
* If the file container does not permit update or replacement, like VMS, the new file name is the name+";" \+version. The file header `name` is not changed

# INDEX

This index tracks all artifacts, specification documents, interview logs, and foundational instruction files created or used during the development of the Personal Knowledge & Executive Assistant System.

* The file is a two column table : `File Name`,`History`
* The cell at column history is a table with `date`,`comment`
* index also has a file header
<!--
# **be-honest** 
 * Format Controllers: Directives that force output structures (e.g., JSON only, Markdown table, Raw code).   
 * Tone & Persona Overrides: Rules that alter style (e.g., Concise mode, ELT10, No fluff, ELI5).  
 * Logic & Reasoning Flags: Directives that modify processing depth (e.g., Step-by-step, Chain of thought, Strict mode  
-->