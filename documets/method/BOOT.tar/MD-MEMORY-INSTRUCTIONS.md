---
name: MEMORY-INSTRUCTIONS
description: prompt to define rules of memory creation and maintenance
metadata:
  node_type: prompt
  type: rule
  project: memory
---
# MEMORY-instructions.md

Rules for maintaining /MEMORY.md. This file is rules only — it does not change often. Project data lives in MEMORY.md, not here.

## Update rules

1. **Read before writing.** Never overwrite blindly — load current MEMORY.md content in full first, then edit.
2. **Edit, don't append-only.** If a fact changes (e.g. a decision is superseded, a status changes), update the existing line in place. Mark superseded items as `(superseded: <date>)` rather than deleting outright, unless the user says to remove it.
3. **Keep it factual and current.** Record decisions, constraints, and state — not narration of the conversation. No "we discussed X" — just the resulting fact.
4. **Prune stale detail.** Task-level status (today's bug, this week's todo) gets removed once resolved. Durable facts (architecture decisions, stack choices, recurring constraints) stay.
5. **Ask before saving anything sensitive** (credentials, tokens, personal data). Never store secrets in MEMORY.md.
6. **Keep sections short.** If a section grows past ~15 lines, summarize/condense rather than letting it sprawl.
7. **Timestamp major edits.** Add a one-line entry to the Changelog section whenever you make a non-trivial update.
8. **Only write what's confirmed.** Don't record assumptions, guesses, or unconfirmed plans as fact — flag them as "proposed" or "TBD" if included at all.

## Fallback behavior

- **MEMORY.md doesn't exist yet:** create it using the template below, ask the user for Project name/purpose to seed it, leave other sections empty rather than guessing.
- **MEMORY.md is too large to read in full:** say so explicitly to the user before proceeding — do not silently skim or truncate. Ask whether to condense it now.
- **MEMORY.md content conflicts with what the user just said in this session:** the user's current statement wins. Update the file to match, and note the change in the Changelog rather than silently picking one version.
- **Unsure whether something belongs in MEMORY.md:** default to leaving it out. Losing a fact the user has to repeat is a smaller cost than the file drifting into an unreliable, bloated record.

## File structure MEMORY.md must follow

```
---
name: MEMORY
description: make context persisten to be preloaded in other sessions 
metadata:
  node_type: memory 
  type: log
---

# MEMORY.md

[Load MEMORY-instructions.md before making any update to this file.]

## Project
- Name / purpose / one-line summary

## Current State
- What's built, what's in progress, what's blocked

## Decisions
- Key technical/product decisions and why (date each)

## Constraints
- Fixed limitations: stack, deadlines, external dependencies

## Open Questions / Next Steps
- Unresolved items to pick up next session

## Changelog
- YYYY-MM-DD: brief note on what changed in this file
```

## Session workflow

- **Start of session:** Load MEMORY.md (which points here). Summarize current state back to the user in 2-3 sentences to confirm shared context before proceeding.
- **End of session (or on request):** Diff what changed against what's recorded, update only the relevant sections, add a Changelog line.
